import { Routes } from "@angular/router";
import { ClienteList } from "./list/cliente.list";
import { ClienteForm } from "./form/cliente.form";
import { ClienteDetail } from "./detail/cliente.detail";

export default [
    
    { path: 'list', component: ClienteList  },
    { path: 'form', component: ClienteForm  },
    { path: 'detail', component: ClienteDetail  }
] as Routes;