import { Component } from '@angular/core';
import { ButtonModule } from "primeng/button";
import { ToastModule } from "primeng/toast";
import { MenubarModule } from "primeng/menubar";
import { IconFieldModule } from "primeng/iconfield";
import { InputIconModule } from "primeng/inputicon";
import { InputTextModule } from 'primeng/inputtext';
import { Route, Router} from '@angular/router';

@Component({
  selector: 'cliente',
  standalone:true,
  imports: [ButtonModule, ToastModule, MenubarModule, IconFieldModule, InputIconModule, InputTextModule],
  templateUrl: './cliente.form.html',
  styleUrl: './cliente.form.scss'
})
export class ClienteForm {

  /**
   *
   */
  constructor(private router: Router) {

  }


  goToCliente() {
    this.router.navigate(['/cliente/list'])
  }

}
